/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'stylescombo', 'gu', {
	label: 'શૈલી/રીત',
	panelTitle: 'ફોર્મેટ ',
	panelTitle1: 'બ્લોક ',
	panelTitle2: 'ઈનલાઈન ',
	panelTitle3: 'ઓબ્જેક્ટ પદ્ધતિ'
});
