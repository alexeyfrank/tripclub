/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'stylescombo', 'sl', {
	label: 'Slog',
	panelTitle: 'Formatting Styles', // MISSING
	panelTitle1: 'Slogi odstavkov',
	panelTitle2: 'Slogi besedila',
	panelTitle3: 'Slogi objektov'
});
