/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'stylescombo', 'pt-br', {
	label: 'Estilo',
	panelTitle: 'Estilos de Formatação',
	panelTitle1: 'Estilos de bloco',
	panelTitle2: 'Estilos de texto corrido',
	panelTitle3: 'Estilos de objeto'
});
